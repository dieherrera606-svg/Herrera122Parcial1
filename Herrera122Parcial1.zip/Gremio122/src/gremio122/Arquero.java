
package gremio122;


public class Arquero extends Aventurero implements Entrenable{
    
    private static final String estiloAtaque = "Precision";
    
    private int precision;
    private int poder;

    public Arquero(String id, String nombre, Rango rango,int precision) {
        super(id, nombre, rango);
        validarPrecision(precision);
        this.precision = precision;
        this.poder = precision * 3;
    }
    
    private static void validarPrecision(int presicion){
        if(presicion < 0){
        throw new IllegalArgumentException("Precision menor a cero");
        }
    }

    @Override
    public String entrenar() {
        return "Aventurero : " + getNombre() + " a comenzado un entrenamiento especial";
    }

    @Override
    public int getPoder() {
        return poder;
    }

    @Override
    public String getEstiloAtaque() {
        return estiloAtaque;
    }
    
    @Override
    public String getDescripcion(){
        return "Aventurero : " + getClass().getSimpleName() + super.toString() + " Ataque de : " + estiloAtaque + " Poder : " + getPoder();
    }
    
}
