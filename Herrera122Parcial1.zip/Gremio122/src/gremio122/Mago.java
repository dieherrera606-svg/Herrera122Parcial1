
package gremio122;



public class Mago extends Aventurero{
    
    private static final String estiloAtaque = "Mana";
    private int mana;
    private int poder;

    public Mago(String id, String nombre, Rango rango,int mana) {
        super(id, nombre, rango);
        validarMana(mana);
        this.mana = mana;
        this.poder = mana + 10;
    }
    
    private static void validarMana(int mana){
        if(mana < 0){
        throw new IllegalArgumentException("Mana menor a cero");
        }
    }

    @Override
    public int getPoder() {
        return poder;
    }

    @Override
    public String getEstiloAtaque() {
        return estiloAtaque;
    }
    
    @Override
    public String getDescripcion(){
        return "Aventurero : " + getClass().getSimpleName() + super.toString() + " Ataque de : " + estiloAtaque + " Poder : " + getPoder();
    }
    
}
