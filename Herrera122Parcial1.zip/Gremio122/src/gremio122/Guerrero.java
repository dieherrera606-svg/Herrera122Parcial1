
package gremio122;


public class Guerrero extends Aventurero implements Entrenable{
    
    private static final String estiloAtaque = "Fuerza";
    
    private int fuerza;
    private int poder;

    public Guerrero(String id, String nombre, Rango rango,int fuerza) {
        super(id, nombre, rango);
        validarFuerza(fuerza);
        this.fuerza = fuerza;
        this.poder = fuerza * 2;
    }
    
    private static void validarFuerza(int fuerza){
        if(fuerza < 0){
        throw new IllegalArgumentException("Fuerza menor a cero");
        }
    }

    @Override
    public String entrenar() {
        return "Aventurero : " + getNombre() + " a comenzado un entrenamiento especial";
    }

    @Override
    public int getPoder() {
        return poder;
    }

    @Override
    public String getEstiloAtaque() {
        return estiloAtaque;
    }
    
    @Override
    public String getDescripcion(){
        return "Aventurero : " + getClass().getSimpleName() + super.toString() + " Ataque de : " + estiloAtaque+ " Poder : " + getPoder();
    }
    
    
}
