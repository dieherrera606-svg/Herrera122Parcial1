
package gremio122;


public interface Entrenable {
    
    String entrenar();
    
}
