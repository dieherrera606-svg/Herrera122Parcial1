
package gremio122;


public enum Rango {
    
    BRONCE,
    PLATA,
    ORO
    
}
