
package gremio122;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Gremio {
    
    private String nombre;
    private List<Aventurero> aventureros;

    public Gremio(String nombre) {
        this.nombre = nombre;
        aventureros = new ArrayList<>();
    }
    
    private static void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("Nombre Invalido");
        }
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    public List<Aventurero> obtenerAventureros(){
        return new ArrayList<>(aventureros);
    }
    
    public void agregarAventurero(Aventurero a){
        validarAventurero(a);
        aventureros.add(a);
    }
    
    private void validarAventurero(Aventurero a){
        Objects.requireNonNull(a);
        if(aventureros.contains(a)){
            throw new AventureroRepetidoException();
        }
    } 
    
    public List<Aventurero> filtrarPorRango (Rango rango){
        List<Aventurero> listaFiltrada = new ArrayList<>();
        
       for(Aventurero a : aventureros){
           if(a.getRango() == rango){
               listaFiltrada.add(a);
           }
       }
       return listaFiltrada;
    }
    
    public List<Aventurero> obtenerAventurerosPoderosos(int poder){
        List<Aventurero> listaFiltrada = new ArrayList<>();
        
        for(Aventurero a : aventureros){
           if(a.getPoder() >= poder){
               listaFiltrada.add(a);
            }
       }
       return listaFiltrada;
    }
    
}
