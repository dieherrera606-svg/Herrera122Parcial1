
package gremio122;


public class AventureroRepetidoException extends RuntimeException{
    
    private static final String MENSAJE = "El aventurero ya se encuentra registrado";

    public AventureroRepetidoException() {
        this(MENSAJE);
    }

    public AventureroRepetidoException(String message) {
        super(message);
    }
    
    
    
}