
package gremio122;


public abstract class Aventurero {
    private String id ;
    private String nombre ;
    private Rango rango;

    public Aventurero(String id, String nombre, Rango rango) {
        validarString(id, "ID Invalida o en blanco");
        validarString(nombre , "Nombre Invalido o en blanco");
        validarRango(rango);
        this.id = id;
        this.nombre = nombre;
        this.rango = rango;
    }
    
    private static void validarString(String s ,String mensaje){
        if(s == null || s.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private static void validarRango(Rango rango){
        if(rango == null){
            throw new IllegalArgumentException("Rango invalido");
        }
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }
    
    public abstract int getPoder();
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Aventurero otro)) {
            return false;
        }

        return id.equals(otro.id)
                && nombre.equals(otro.nombre);
        }

    @Override
    public String toString() {
        return  " Nombre : " + nombre + " ID : " + id + " Rango : " + rango;
    }
    
    public abstract String getDescripcion();
    
    public abstract String getEstiloAtaque();
    
}
